# Peripherals Examples

This section provides examples how to configure and use ESP32’s internal peripherals like GPIO, UART, I2C, SPI, timers, counters, ADC / DAC, PWM, etc.

See the [README.md](../README.md) file in the upper level [examples](../) directory for more information about examples.
