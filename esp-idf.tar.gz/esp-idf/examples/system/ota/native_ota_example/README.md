# Native OTA example

This example is based on `app_update` component's APIs.

## Configuration

Refer the README.md in the parent directory for the setup details.