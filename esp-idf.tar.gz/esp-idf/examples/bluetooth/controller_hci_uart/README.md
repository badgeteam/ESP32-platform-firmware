ESP-IDF UART HCI Controller
===========================

This is a btdm controller use UART as HCI IO. This require the UART device support RTS/CTS mandatory.
It can do the configuration of UART number and UART baudrate by menuconfig.


