import sndmixer, display, time, os, version, neopixel, _thread, system

sndmixer.begin(2)
neopixel.enable()

ledStop = False
def ledThread():
  global ledStop
  ledState = 0
  ledData = [0x00, 0x00, 0x00]*12
  while True:
	for i in range(len(ledData)):
	  if ledData[i] > 64:
		ledData[i] -= 64
	  else:
		ledData[i] = 0
	if not ledStop:
	  ledData[ledState*3] = 0xFF
	  ledData[(11-ledState)*3+1] = 0xFF
	  ledData[ledState*3+2] = 0xFF
	  ledData[(11-ledState)*3+2] = 0xFF
	neopixel.send(bytes(ledData))
	ledState = ledState + 1
	if ledState > 11:
	  ledState = 0
	time.sleep_ms(50)

_thread.start_new_thread("LED", ledThread, ())

directory = '/'.join(__file__.split('/')[:-1])

bgmFile = open(directory+"/bgm22050.mp3", "rb")
bgmId = sndmixer.mp3_stream(bgmFile)
sndmixer.volume(bgmId, 50)

files = os.listdir(directory)
pngFiles = []
for file in files:
  if file.endswith(".png") and file != "icon.png":
	pngFiles.append(file)
pngFiles.sort()
for i in range(4): #Repeat 4 times
  for file in pngFiles:
	  print("Now showing", file)
	  pngFile = open(directory+"/"+file, "rb")
	  pngData = pngFile.read()
	  pngFile.close()
	  display.drawFill(0x000000)
	  try:
		display.drawPng(0,0,pngData)
	  except:
		print("Rendering error in", file)
		display.drawFill(0x000000)
		display.drawText(0,0,"Rendering error!", 0xFFFFFF, "7x5")
		display.drawText(0,6,file, 0xFFFFFF, "7x5")
	  display.flush()
	  time.sleep(2)

#display.drawFill(0)
#display.flush()
ledStop = True
for i in range(50):
  sndmixer.volume(bgmId, 50-i)
  time.sleep_ms(10)
system.home()
