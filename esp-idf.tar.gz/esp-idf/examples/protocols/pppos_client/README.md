#PPP over Serial (PPPoS) client example

It shows example of ppp client using lwip PPPoS api and GSM.
Before you run this example, make sure your GSM is in command mode
and is registered to network.

PPP over serial support is experimental and unsupported. This example was tested with GSM Telit GL865-DUAL V3.

See the README.md file in the upper level 'examples' directory for more information about examples.
