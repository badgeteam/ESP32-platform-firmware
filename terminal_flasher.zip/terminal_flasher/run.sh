#!/bin/bash
python3 terminalflash.py /dev/ttyUSB0 /dev/ttyUSB1 /dev/ttyUSB2 /dev/ttyUSB3 ./ ./esptool.py 
