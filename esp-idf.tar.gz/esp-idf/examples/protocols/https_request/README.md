# HTTPS Request Example

Uses APIs from `esp-tls` component to make a very simple HTTPS request over a secure connection, including verifying the server TLS certificate.

See the README.md file in the upper level 'examples' directory for more information about examples.
